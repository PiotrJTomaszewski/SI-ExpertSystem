# Summer Reading Book Recommendation
Created by Szymon Michalak and Piotr Tomaszewski.

For Artificial Intelligence course at PUT.

Based on a flowchart by [teach.com](teach.com).

## Compilation
mvn clean compile

## Running
mvn clean package exec:java
