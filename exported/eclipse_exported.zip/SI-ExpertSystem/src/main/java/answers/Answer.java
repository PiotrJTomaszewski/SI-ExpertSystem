package answers;

public class Answer {
	public String question;
	public String answer;
	public Answer(String question, String answer){
		this.question = question;
		this.answer = answer;
	}
}